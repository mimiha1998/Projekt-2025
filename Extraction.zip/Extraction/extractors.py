"""
Updated 6 December 2021 from Feb 5-10,2019 version
- contains functions that are called from mega_collector.py to extract lang-independent features from conllu format;
- calls functions from helpfunctions.py to traverse conllu sentence trees
- each word is represented as: int(identifier), token, lemma, upos, xpos, feats, int(head), rel
- pip install igraph  (library by Tamas Nepusz)
"""
import sys
import numpy as np
from igraph import *
from igraph._igraph import arpack_options
from helpfunctions import has_kid_by_lemlist, has_auxkid_by_tok

def av_s_length(trees, lang):
    sent_lengths = []
    if lang == 'en':
        texts = trees.copy()
        for i, tree in enumerate(texts):
            if i < len(texts):
                lastwd = tree[-1]
                if lastwd[1] in [':', ';', 'Mr.', 'Dr.']:
                    if len(texts) > i + 1:
                        nextsent = texts[i + 1]
                        sent_lengths.append(len(tree) + len(nextsent))
                        texts.remove(texts[i + 1])
                    else:
                        sent_lengths.append(len(tree))
                else:
                    sent_lengths.append(len(tree))
    elif lang == 'es':
        texts = trees.copy()
        for i, tree in enumerate(texts):
            if i < len(texts):
                lastwd = tree[-1]
                if lastwd[1] in [':', ';']:
                    try:
                        nextsent = texts[i + 1]
                        sent_lengths.append(len(tree) + len(nextsent))
                        texts.remove(texts[i + 1])
                    except IndexError:
                        sent_lengths.append(len(tree))
                        print('Despite filtering I still have texts that finish in no end-of-sent punct!')
                        print(' '.join(w[1] for w in tree))
                        continue
                else:
                    sent_lengths.append(len(tree))
    elif lang == 'de':
        texts = trees.copy()
        for i, tree in enumerate(texts):
            if i < len(texts):
                lastwd = tree[-1]
                if lastwd[1] in [':', ';', 'Hr.', 'Dr.', 'Prof.']:
                    if len(texts) > i + 1:
                        nextsent = texts[i + 1]
                        sent_lengths.append(len(tree) + len(nextsent))
                        texts.remove(texts[i + 1])
                    else:
                        sent_lengths.append(len(tree))
                else:
                    sent_lengths.append(len(tree))
    return np.average(sent_lengths)

def word_length(tree):
    words = 0
    letters = 0
    for el in tree:
        if not el[1] in ['.', ',', '!', '?', ':', ';', '"', '-', '—', '(', ')']:
            words += 1
            letters += len(el[1])
    if words == 0:
        print(tree)
    av_wordlength = letters / words if words > 0 else 0
    return av_wordlength

def interrog(tree):
    count = 0
    matches = []
    if len(tree) >= 2:
        last = tree[-1]
        lastbut = tree[-2]
        if tree[-1][2] == '?' or tree[-2][2] == '?':
            count += 1
            matches.append(last[2])
            matches.append(lastbut[2])
    return count, matches

def nn(tree):
    count = 0
    matches = []
    for w in tree:
        lemma = w[2].lower()
        if 'NOUN' in w[3]:
            count += 1
            matches.append(lemma)
    return count, matches

def test_sanity(tree):
    arpack_options.maxiter = 3000
    bad_trees = 0
    sentence_graph = Graph(len(tree) + 1)

    sentence_graph = sentence_graph.as_directed()
    sentence_graph.vs["name"] = ['ROOT'] + [word[1] for word in tree]
    sentence_graph.vs["label"] = sentence_graph.vs["name"]
    edges = [(word[6], word[0]) for word in tree if word[7] != 'punct']
    try:
        sentence_graph.add_edges(edges)
        sentence_graph.vs.find("ROOT")["shape"] = 'diamond'
        sentence_graph.vs.find("ROOT")["size"] = 40
        disconnected = [vertex.index for vertex in sentence_graph.vs if vertex.degree() == 0]
        sentence_graph.delete_vertices(disconnected)
    except:
        bad_trees += 0
    return sentence_graph

def speakdiff(tree):
    graph = test_sanity(tree)
    parts = graph.components(mode=WEAK)
    mhd = 0
    errors = 0
    if len(parts) == 1:
        nodes = [word[1] for word in tree if word[7] != 'punct' and word[7] != 'root']
        all_hds = []
        for node in nodes:
            try:
                hd = graph.shortest_paths_dijkstra('ROOT', node, mode=ALL)
                all_hds.append(hd[0][0])
            except ValueError:
                errors += 1
        if all_hds:
            mhd = np.average(all_hds)
    return mhd
def readerdiff(tree):
    s = [q for q in tree if q[7] != 'punct']
    inbtw = []
    if len(s) > 1:
        for s_word_id in range(len(s)):
            w = s[s_word_id]
            head_id = w[6]
            if head_id == 0:
                continue
            s_head_id = None
            for s_word_id_2 in range(len(s)):
                w1 = s[s_word_id_2]
                if head_id == w1[0]:
                    s_head_id = s_word_id_2
                    break
            dd = abs(s_word_id - s_head_id) - 1
            inbtw.append(dd)
    mdd = np.average(inbtw) if inbtw else 0
    return mdd

def content_ty_to(tree):
    content_types = []
    content_tokens = []
    for w in tree:
        if w[3] in ['ADJ', 'ADV', 'VERB', 'NOUN']:
            content_type = w[2] + '_' + w[3]
            content_types.append(content_type)
            content_token = w[1] + '_' + w[3]
            content_tokens.append(content_token)
    return len(set(content_types)), len(content_tokens)

def finites(tree):
    fins = 0
    for w in tree:
        if 'VerbForm=Fin' in w[5]:
            fins += 1
    return fins

def attrib(tree):
    count = 0
    matches = []
    for w in tree:
        if ('ADJ' in w[3] or 'VerbForm=Part' in w[5]) and 'amod' in w[7]:
            count += 1
            matches.append(w[2])
    return count, matches

def pasttense(tree):
    count = 0
    for w in tree:
        if 'Tense=Past' in w[5]:
            count += 1
    return count

def count_dms(searchlists, trees, lang):
    res = 0
    
    # Vereinfachte Spracherkennung
    if isinstance(lang, str):
        lang = lang.lower()
        if 'de' in lang:
            lang = 'de'
        elif 'en' in lang:
            lang = 'en'
        elif 'es' in lang:
            lang = 'es'
    
    # Deutsche Listen separat verarbeiten
    if lang == 'de':
        try:
            import os
            current_dir = os.getcwd()
            searchlist_dir = os.path.join(current_dir, 'searchlists')
            
            # Deutsche Listen
            list_files = [
                'de_adv_quantifiers.lst',
                'de_converts.lst',
                'de_deverbals_stop.lst',
                'de_modal-adj_predicates.lst'
            ]
            
            # Listen laden
            de_words = []
            for list_file in list_files:
                file_path = os.path.join(searchlist_dir, list_file)
                if os.path.exists(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        words = [line.strip() for line in f if line.strip()]
                        de_words.extend(words)
            
            # Wörter in Bäumen suchen
            for tree in trees:
                sent = ' '.join(w[1] for w in tree)
                for word in de_words:
                    if not word:
                        continue
                    padded = f' {word} '
                    if padded in f' {sent} ':
                        res += 1
                    elif f' {word.capitalize()} ' in f' {sent} ':
                        res += 1
            return res
            
        except Exception as e:
            print(f"Error processing German lists: {str(e)}", file=sys.stderr)
            return 0
    
    # Englisch und Spanisch verarbeiten
    if lang not in searchlists:
        print(f"Warning: Language '{lang}' not found in searchlists. Available languages: {list(searchlists.keys())}", file=sys.stderr)
        return 0
        
    lst = searchlists[lang]
    
    for tree in trees:
        sent = ' '.join(w[1] for w in tree)
        for i in lst:
            i = i.strip()
            try:
                if i[0].isupper():
                    padded0 = i + ' '
                    if padded0 in sent:
                        res += 1
                else:
                    padded1 = ' ' + i + ' '
                    if padded1 in sent or i.capitalize() + ' ' in sent:
                        res += 1
            except IndexError:
                continue
    return res        

    

def get_epistemic_stance(trees, lang):
    verbs = 0
    for tree in trees:
        if lang == 'en':
            sent = ' '.join(w[1] for w in tree)
            for w in tree:
                if w[1] in ['argue', 'doubt', 'assume', 'believe', 'find'] \
                        and has_kid_by_lemlist(w, tree, ['I', 'we']) \
                        and not has_auxkid_by_tok(w, tree, 'did'):
                    verbs += 1
                if w[1] == 'say' and has_auxkid_by_tok(w, tree, 'would') \
                        and has_kid_by_lemlist(w, tree, ['I', 'we']):
                    verbs += 1
                if w[1] in ['convinced', 'persuaded'] and has_kid_by_lemlist(w, tree, ['be']) \
                        and has_kid_by_lemlist(w, tree, ['I', 'we']):
                    verbs += 1
                if w[1] == 'feel' and has_kid_by_lemlist(w, tree, ['I', 'we']) \
                        and ('feel like' in sent or 'feel that' in sent):
                    verbs += 1
        elif lang == 'es':
            continue
        elif lang == 'de':
            sent = ' '.join(w[1] for w in tree)
            for w in tree:
                if w[1] in ['meinen', 'glauben', 'denken', 'vermuten', 'annehmen'] \
                        and has_kid_by_lemlist(w, tree, ['ich', 'wir']) \
                        and not has_auxkid_by_tok(w, tree, 'hatte'):
                    verbs += 1
                if w[1] == 'sagen' and has_auxkid_by_tok(w, tree, 'würde') \
                        and has_kid_by_lemlist(w, tree, ['ich', 'wir']):
                    verbs += 1
                if w[1] in ['überzeugt', 'sicher'] and has_kid_by_lemlist(w, tree, ['sein']) \
                        and has_kid_by_lemlist(w, tree, ['ich', 'wir']):
                    verbs += 1
    return verbs
def sents_complexity(trees):
    types = ['csubj', 'acl:relcl', 'advcl', 'acl', 'xcomp', 'parataxis']
    simples = 0
    clauses_counts = []
    for tree in trees:
        this_sent_cls = 0
        for w in tree:
            if w[7] in types:
                this_sent_cls += 1
        if this_sent_cls == 0:
            simples += 1
        clauses_counts.append(this_sent_cls)
    return np.average(clauses_counts), simples / len(trees)

def relation_counts(tree, i_relations):
    sent_relations = [w[7] for w in tree]
    counts = {rel: sent_relations.count(rel) for rel in i_relations}
    return counts

def ud_freqs(trees, udfeats_=None):
    relations = udfeats_
    relations_d = {rel: [] for rel in relations}
    for tree in trees:
        rel_distribution = relation_counts(tree, relations_d)
        for rel in relations_d.keys():
            relations_d[rel].append(rel_distribution[rel])
    
    dict_out = {}
    for rel in relations_d.keys():
        dict_out[rel] = np.average(relations_d[rel])
    return dict_out

def relation_distribution(tree, i_relations):
    sent_relations = [w[7] for w in tree]
    distribution = {rel: sent_relations.count(rel) for rel in i_relations}
    total = sum(distribution.values())
    if total:
        for key in distribution:
            distribution[key] /= total
    return distribution

def ud_probabilities(trees, udfeats_=None):
    relations = udfeats_
    relations_d = {rel: [] for rel in relations}
    for tree in trees:
        rel_distribution = relation_distribution(tree, relations_d)
        for rel in relations_d.keys():
            relations_d[rel].append(rel_distribution[rel])
    
    dict_out = {}
    for rel in relations_d.keys():
        dict_out[rel] = np.average(relations_d[rel])
    return dict_out

def nouns_to_all(trees):
    count = 0
    nouns = 0
    for tree in trees:
        for w in tree:
            if w[7] in ['nsubj', 'obj', 'iobj']:
                count += 1
                if w[3] in ['NOUN', 'PROPN']:
                    nouns += 1
    res = nouns / count if count > 0 else 0
    return res

def prsp(tree, lang):
    count = 0
    matches = []
    for w in tree:
        token = w[1].lower()
        if lang == 'en':
            if 'PRON' in w[3] and 'Person=' in w[5] and 'Poss=Yes' not in w[5]:
                if token in ['i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them']:
                    count += 1
                    matches.append(w[2].lower())
        elif lang == 'es':
            if 'PRON' in w[3] and 'Person=' in w[5] and 'Poss=Yes' not in w[5]:
                if token in "yo tú vos usted él ella nosotros nosotras ustedes vosotros vosotras ellos ellas me te lo nos os los la las se le les mí ti sí conmigo contigo consigo".split():
                    count += 1
                    matches.append(w[2].lower())
        elif lang == 'de':
            if 'PRON' in w[3] and 'Person=' in w[5] and 'Poss=Yes' not in w[5]:
                if token in "ich du er sie es wir ihr sie mich dich ihn uns euch ihnen mir dir ihm ihr uns euch ihnen".split():
                    count += 1
                    matches.append(w[2].lower())
    return count, matches

def possdet(tree, lang):
    count = 0
    matches = []
    for w in tree:
        lemma = w[2].lower()
        if lang == 'en':
            if lemma in ['my', 'your', 'his', 'her', 'its', 'our', 'their']:
                if w[3] in ['DET', 'PRON'] and 'Poss=Yes' in w[5]:
                    count += 1
                    matches.append(w[2].lower())
        elif lang == 'es':
            if lemma in "mi mis tu tus su sus nuestro nuestros nuestra nuestras vuestro vuestros vuestra vuestras".split():
                if w[3] in ['DET', 'PRON'] and 'Poss=Yes' in w[5]:
                    count += 1
                    matches.append(w[2].lower())
        elif lang == 'de':
            if lemma in "mein meine meiner meines meinem meinen dein deine deiner deines deinem deinen sein seine seiner seines seinem seinen ihr ihre ihrer ihres ihrem ihren unser unsere unserer unseres unserem unseren euer eure eurer eures eurem euren".split():
                if w[3] in ['DET', 'PRON'] and 'Poss=Yes' in w[5]:
                    count += 1
                    matches.append(w[2].lower())
    return count, matches

def anysome(tree, lang):
    count = 0
    matches = []
    for w in tree:
        if lang == 'en':
            if w[2] in ['anybody', 'anyone', 'anything', 'everybody', 'everyone', 'everything',
                        'nobody', 'none', 'nothing', 'somebody', 'someone', 'something',
                        'elsewhere', 'nowhere', 'everywhere', 'somewhere', 'anywhere']:
                count += 1
                matches.append(w[2].lower())
        elif lang == 'es':
            annotated_types = ['PronType=Ind', 'PronType=Tot', 'PronType=Int,Rel', 'PronType=Neg']
            if w[2] in "todo toda todos todas ambos ambas cada cada uno cada una alguno alguna algunos algunas algún ninguno ninguna ningunos ningunas ningún alguien algo nada nadie varios varias cualquiera cualesquiera cuánto cuánta cuántos cuántas tonto tanta tantos tantas tan mucho mucha muchos muchas muy poco poca pocos pocas bastante bastantes demasiado demasiada demasiados demasiadas más menos".split() and any(s in w[5] for s in annotated_types):
                count += 1
                matches.append(w[2].lower())
        elif lang == 'de':
            annotated_types = ['PronType=Ind', 'PronType=Tot', 'PronType=Int,Rel', 'PronType=Neg']
            if w[2] in "alle alles jeder jede jedes jeglicher jegliche jegliches mancher manche manches einiger einige einiges etlicher etliche etliches irgendein irgendeine irgendeines irgendwelcher irgendwelche irgendwelches kein keine keines niemand nichts nirgends irgendwo überall".split() and any(s in w[5] for s in annotated_types):
                count += 1
                matches.append(w[2].lower())
    return count, matches

def cconj(tree, lang):
    count = 0
    matches = []
    for w in tree:
        if lang == 'en':
            if 'CCONJ' in w[3] and w[2] in ['and', 'but', 'or', 'both', 'yet', 'either',
                                            '&', 'nor', 'plus', 'neither', 'ether']:
                count += 1
                matches.append(w[2].lower())
        elif lang == 'es':
            if 'CCONJ' in w[3] and w[2] in "y e ni o u ni pero sino más tanto como cuanto así como sea ya bien".split():
                count += 1
                matches.append(w[2].lower())
        elif lang == 'de':
            if 'CCONJ' in w[3] and w[2] in "und oder aber sondern denn sowie sowohl weder noch".split():
                count += 1
                matches.append(w[2].lower())
    return count, matches

def sconj(tree, lang):
    count = 0
    matches = []
    for w in tree:
        if lang == 'en':
            if 'SCONJ' in w[3] and w[2] in ['that', 'how', 'if', 'after', 'before', 'when', 'as', 'while', 'because',
                                            'for', 'whether', 'although', 'though', 'since', 'once', 'so', 'until',
                                            'despite', 'unless', 'whereas', 'whilst']:
                count += 1
                matches.append(w[2].lower())
        elif lang == 'es':
            if 'SCONJ' in w[3] and w[2] in "así aun aunque como conque cuando donde luego por porque pues que salvo si".split():
                count += 1
                matches.append(w[2].lower())
        elif lang == 'de':
            if 'SCONJ' in w[3] and w[2] in "dass wenn als ob weil da nachdem bevor während seit bis damit falls sofern solange soviel soweit wobei wodurch worin worauf".split():
                count += 1
                matches.append(w[2].lower())
    return count, matches

def polarity(tree, lang):
    negs = 0
    for w in tree:
        if lang == 'en':
            if w[2] in ['no', 'not', 'neither']:
                negs += 1
        elif lang == 'es':
            if w[2] in ['no', 'ni']:
                negs += 1
        elif lang == 'de':
            if w[2] in ['nicht', 'kein', 'keine', 'keines', 'keinem', 'keinen', 'nie', 'niemals', 'nirgends']:
                negs += 1
    return negs

def copulas(tree):
    copcount = 0
    for i, w in enumerate(tree):
        if w[7] == "cop" and w[2] in ['be', 'ser', 'estar', 'sein']:
            try:
                for prev_w in [tree[i - 1], tree[i - 2], tree[i - 3]]:
                    if prev_w[2] == 'there':
                        copcount += -1
            except IndexError:
                copcount += 1
            copcount += 1
    return copcount

def demdeterm(tree, lang):
    res = 0
    for w in tree:
        if lang == 'en':
            if w[7] == 'det' and w[2] in ['the', 'a', 'this', 'some', 'these', 'that', 'any', 'all',
                                          'every', 'another', 'each', 'those', 'either', 'such']:
                res += 1
        elif lang == 'es':
            if w[7] == 'det' and w[2] in "el la los las lo al del un una unos unas este esta esto estos estas ese esa eso esos esas aquel aquella aquello aquellos aquellas tanto tanta tantos tantas tal tales tan".split():
                res += 1
        elif lang == 'de':
            if w[7] == 'det' and w[2] in "der die das den dem des ein eine eines einem einen dieser diese dieses diesen diesem jener jene jenes jenen jenem welcher welche welches welchen welchem".split():
                res += 1
    return res

def propn(tree):
    res = 0
    for w in tree:
        if w[3] == 'SCONJ':
            res += 1
    return res

def preps(tree, lang):
    res = 0
    for w in tree:
        if lang == 'en':
            if w[3] == 'ADP' and w[2] in ['of', 'in', 'unlike', 'for', 'at', 'as', 'to', 'along', 'with', 'after',
                                          'on', 'towards', 'amongst', 'within', 'over', 'during', 'by', 'against',
                                          'about', 'out', 'from', 'without', 'into', 'like', 'up', 'between',
                                          'before', 'down', 'across', 'per', 'off', 'around', 'since', 'onto',
                                          'through', 'beyond', 'under', 'despite', 'than', 'until', 'because',
                                          'upon', 'among', 'back', 'behind', 'past', 'outside', 'throughout',
                                          'inside', 'via', 'above', 'alongside', 'versus', 'below', 'round']:
                res += 1
        elif lang == 'es':
            if w[3] == 'ADP' and w[2] in "a ante bajo con contra de desde durante en entre hacia hasta mediante para por según sin sobre tras excepto salvo incluso".split():
                res += 1
        elif lang == 'de':
            if w[3] == 'ADP' and w[2] in "in an auf mit bei aus von zu nach über unter durch für gegen ohne um bei neben zwischen hinter vor".split():
                res += 1
    return res