import os
import csv
import sys
from extractors import av_s_length, word_length, interrog, nn, speakdiff, readerdiff, content_ty_to, finites,
    attrib, pasttense, count_dms, get_epistemic_stance, sents_complexity, ud_probabilities, ud_freqs, nouns_to_all
from extractors import prsp, possdet, anysome, cconj, sconj, copulas, polarity, demdeterm, propn, preps
from helpfunctions import dms_support_all_langs, get_trees, wordcount, sents_num, verbs_num
from collections import defaultdict
import time
import argparse

def safe_divide(a, b, default=0):
    try:
        return a / b if b != 0 else default
    except:
        return default

def initialize_current_dict(keys, doc_name, language='en'):
    current = dict.fromkeys(keys, 0)
    current['doc'] = doc_name
    current['lang'] = language
    return current

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help="Path to folder with *.conllu files")
    parser.add_argument('--output', required=True, help="Path and name of the output file")
    parser.add_argument('--supports', default='./searchlists/', help="Folder with DM lists")
    parser.add_argument('--minlen', default=2, type=int, help="Minimum sentence length")
    parser.add_argument('--langs', nargs='+', default=['en', 'es', 'de'], help='Languages to process')

    args = parser.parse_args()
    start = time.time()

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    input_dir = args.input
    outname = args.output

    ud_features = 'sentlength wdlength interrog nn mhd mdd content_dens content_TTR finites attrib pasttense addit advers caus tempseq epist numcls simple nnargs ppron possp intonep cconj sconj neg copula determ propn adp'.split()
    all_udrels = ['acl', 'advcl', 'advmod', 'amod', 'appos', 'aux:pass', 'case', 'cc', 'ccomp', 'clf', 'compound', 'dep', 'discourse', 'dislocated', 'expl', 'fixed', 'flat', 'goeswith', 'iobj', 'list', 'mark', 'nmod', 'nsubj', 'nummod', 'obj', 'obl', 'orphan', 'parataxis', 'reparandum', 'vocative', 'xcomp']

    keys = ['doc', 'lang', 'wc', 'sents'] + ud_features + all_udrels
    master_dict = {k: [] for k in keys}
    basic_stats = defaultdict(int)
    languages = args.langs

    additive = {}
    adversative = {}
    causal = {}
    sequen = {}
    epistem = {}

    for lang in languages:
        try:
            if lang in ['en', 'es']:
                addit, advers, caus, seque, epist = dms_support_all_langs(lang, lists_path=args.supports)
                additive[lang] = addit
                adversative[lang] = advers
                causal[lang] = caus
                sequen[lang] = seque
                epistem[lang] = epist

                print('---')
                print(f'Importing DM searchlists for {lang.upper()}:')
                print(f'=={len(additive[lang])} additive')
                print(f'=={len(adversative[lang])} adversative')
                print(f'=={len(causal[lang])} causative')
                print(f'=={len(sequen[lang])} temporal/sequencial')
                print(f'=={len(epistem[lang])} DM of epistemic stance')

            elif lang == 'de':
                additive[lang] = []
                adversative[lang] = []
                causal[lang] = []
                sequen[lang] = []
                epistem[lang] = []
                print('---')
                print(f'DE: using internal loading of DM searchlists from extractors.py')
        except Exception as e:
            print(f"Warning: Error loading searchlists for {lang}: {str(e)}", file=sys.stderr)

    processed_files = 0
    valid_files = 0
    total_sentences = 0
    counter = 0

    for subdir, dirs, files in os.walk(input_dir):
        for i, file in enumerate(files):
            if not file.endswith('.conllu'):
                continue

            processed_files += 1
            filepath = os.path.join(subdir, file)

            try:
                file_lang = None
                normalized_path = filepath.replace("\\", "/").lower()
                normalized_name = file.lower()

                for lang in languages:
                    if (
                        f"/{lang}/" in normalized_path or
                        f"\\{lang}\\" in filepath.lower() or
                        f"_{lang}" in normalized_name or
                        f".{lang}." in normalized_name or
                        normalized_name.endswith(f".{lang}.conllu") or
                        normalized_name.endswith(f"_{lang}.conllu")
                    ):
                        file_lang = lang
                        break

                if not file_lang:
                    print(f"❗ Warning: Could not determine language for {filepath}")
                    continue
                else:
                    print(f"✅ Sprache erkannt: {file_lang} → {file}")

                try:
                    data = open(filepath, encoding="utf-8").readlines()
                except UnicodeDecodeError:
                    data = open(filepath, encoding="ISO-8859-1").readlines()

                sents, bads, shorts = get_trees(data, minlen=args.minlen)

                if len(sents) > 0:
                    valid_files += 1
                    total_sentences += len(sents)
                    doc = os.path.splitext(file)[0]
                    current = initialize_current_dict(keys, doc, file_lang)

                    normBy_wc = wordcount(sents)
                    normBy_sentnum = sents_num(sents, file_lang)
                    normBy_verbnum = verbs_num(sents)

                    if normBy_sentnum > 0:
                        wdlength_res = interrog_res = nn_res = speakdiff_res = readerdiff_res = 0
                        content_ty_res = content_to_res = finites_res = attrib_res = pasttense_res = 0
                        ppron_res = possdet_res = anysome_res = cconj_res = sconj_res = 0
                        demdets_res = copula_res = propn_res = adp_res = neg_res = 0

                        avsents = av_s_length(sents, file_lang)
                        addit_res = count_dms(additive, sents, file_lang)
                        advers_res = count_dms(adversative, sents, file_lang)
                        caus_res = count_dms(causal, sents, file_lang)
                        tempseq_res = count_dms(sequen, sents, file_lang)
                        epist_res = count_dms(epistem, sents, file_lang) + get_epistemic_stance(sents, file_lang)
                        numcls_res, simple_res = sents_complexity(sents)
                        nnargs_res = nouns_to_all(sents)

                        for sent in sents:
                            mhd = speakdiff(sent)
                            if mhd:
                                speakdiff_res += mhd
                                readerdiff_res += readerdiff(sent)

                            wdlength_res += word_length(sent)
                            interrog_res += interrog(sent)[0]
                            nn_res += nn(sent)[0]
                            attrib_res += attrib(sent)[0]
                            pasttense_res += pasttense(sent)
                            ty, to = content_ty_to(sent)
                            content_ty_res += ty
                            content_to_res += to
                            finites_res += finites(sent)

                            ppron_res += prsp(sent, file_lang)[0]
                            possdet_res += possdet(sent, file_lang)[0]
                            anysome_res += anysome(sent, file_lang)[0]
                            cconj_res += cconj(sent, file_lang)[0]
                            sconj_res += sconj(sent, file_lang)[0]
                            demdets_res += demdeterm(sent, file_lang)
                            copula_res += copulas(sent)
                            neg_res += polarity(sent, file_lang)
                            propn_res += propn(sent)
                            adp_res += preps(sent, file_lang)

                        current.update({
                            'wc': normBy_wc,
                            'sents': normBy_sentnum,
                            'sentlength': avsents if avsents is not None else 0,
                            'wdlength': safe_divide(wdlength_res, normBy_sentnum),
                            'interrog': safe_divide(interrog_res, normBy_sentnum),
                            'nn': safe_divide(nn_res, normBy_wc),
                            'mhd': safe_divide(speakdiff_res, normBy_sentnum),
                            'mdd': safe_divide(readerdiff_res, normBy_sentnum),
                            'content_dens': safe_divide(content_ty_res, normBy_wc),
                            'content_TTR': safe_divide(content_ty_res, content_to_res),
                            'finites': safe_divide(finites_res, normBy_verbnum),
                            'attrib': safe_divide(attrib_res, normBy_sentnum),
                            'pasttense': safe_divide(pasttense_res, normBy_sentnum),
                            'addit': safe_divide(addit_res, normBy_sentnum),
                            'advers': safe_divide(advers_res, normBy_sentnum),
                            'caus': safe_divide(caus_res, normBy_sentnum),
                            'tempseq': safe_divide(tempseq_res, normBy_sentnum),
                            'epist': safe_divide(epist_res, normBy_sentnum),
                            'numcls': numcls_res or 0,
                            'simple': simple_res or 0,
                            'nnargs': nnargs_res or 0,
                            'ppron': safe_divide(ppron_res, normBy_wc),
                            'possp': safe_divide(possdet_res, normBy_wc),
                            'intonep': safe_divide(anysome_res, normBy_wc),
                            'cconj': safe_divide(cconj_res, normBy_sentnum),
                            'sconj': safe_divide(sconj_res, normBy_sentnum),
                            'copula': safe_divide(copula_res, normBy_sentnum),
                            'neg': safe_divide(neg_res, normBy_sentnum),
                            'determ': safe_divide(demdets_res, normBy_wc),
                            'propn': safe_divide(propn_res, normBy_sentnum),
                            'adp': safe_divide(adp_res, normBy_wc)
                        })

                        dep_dict = ud_freqs(sents, udfeats_=all_udrels)
                        for k, val in dep_dict.items():
                            current[k] = safe_divide(val, normBy_sentnum)

                        for key in master_dict.keys():
                            master_dict[key].append(current[key])
                        counter += 1

            except Exception as e:
                print(f"Error processing {filepath}: {str(e)}", file=sys.stderr)
                continue

    if counter > 0:
        print(f"\nWriting {counter} documents to output file...")
        try:
            with open(outname, "w", encoding='utf-8', newline='') as outfile:
                writer = csv.writer(outfile, delimiter="\t")
                writer.writerow(keys)
                writer.writerows(zip(*[master_dict[key] for key in keys]))
            print(f"Successfully wrote data to {outname}")
        except Exception as e:
            print(f"Error saving results: {str(e)}", file=sys.stderr)
    else:
        print("No valid documents to write!")

    print(f"\nFinal Processing Summary:")
    print(f"Total files processed: {processed_files}")
    print(f"Files with valid sentences: {valid_files}")
    print(f"Total sentences processed: {total_sentences}")
    print(f"Documents in output: {counter}")
    print("Documents per language:")
    lang_counts = defaultdict(int)
    for lang in master_dict['lang']:
        lang_counts[lang] += 1
    for lang, count in lang_counts.items():
        print(f"- {lang}: {count}")
    print(f"Features extracted: {len(ud_features)} custom + {len(all_udrels)} UD tags")

    end = time.time()
    print(f'Processing took {(end - start) / 60:.2f} minutes')